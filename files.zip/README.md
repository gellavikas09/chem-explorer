# 🧪 Chemical Property Explorer

A Streamlit app to view and compare physical and chemical properties of compounds
(Benzene, Toluene, Aniline, Wurtzite Boron Nitride).

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
Push this folder to GitHub, then deploy `app.py` on [Streamlit Community Cloud](https://share.streamlit.io).

## Add a compound
Copy an entry in the `COMPOUNDS` dictionary in `app.py` and edit the values.

> Values are approximate literature data; verify with an SDS or the CRC Handbook.
